import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(request: Request) {
  try {
    const { id } = await request.json();
    
    if (!id) {
      return NextResponse.json({ error: 'ID is required' }, { status: 400 });
    }

    const applicant = await prisma.ppdbApplicant.update({
      where: { id },
      data: { paymentStatus: 'PAID' }
    });

    return NextResponse.json({ success: true, applicant });
  } catch (error) {
    console.error('Error updating payment status:', error);
    return NextResponse.json({ error: 'Gagal memperbarui status' }, { status: 500 });
  }
}
