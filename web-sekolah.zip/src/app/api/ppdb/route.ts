import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    // Check if NISN already exists
    const existingApplicant = await prisma.ppdbApplicant.findUnique({
      where: { nisn: data.nisn }
    });

    if (existingApplicant) {
      return NextResponse.json(
        { error: 'NISN sudah terdaftar' },
        { status: 400 }
      );
    }

    const applicant = await prisma.ppdbApplicant.create({
      data: {
        jalur: data.jalur,
        fullName: data.fullName,
        nisn: data.nisn,
        birthInfo: data.birthInfo,
        gender: data.gender,
        address: data.address,
        phone: data.phone,
        previousSchool: data.previousSchool,
        major: data.major,
        afirmasiNumber: data.afirmasiNumber || null,
        prestasiType: data.prestasiType || null,
        paymentStatus: data.jalur === 'normal' ? 'UNPAID' : 'PAID', // Simulasi: normal bayar, lainnya gratis
        status: 'PENDING'
      }
    });

    return NextResponse.json({ success: true, applicant }, { status: 201 });
  } catch (error: any) {
    console.error('Error creating PPDB applicant:', error);
    return NextResponse.json(
      { error: 'Gagal mendaftar. Silakan coba lagi.' },
      { status: 500 }
    );
  }
}
