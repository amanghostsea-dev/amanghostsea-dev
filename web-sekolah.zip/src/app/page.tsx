import Image from "next/image";
import { ArrowRight, BookOpen, Calendar, GraduationCap, LayoutDashboard, Users, Trophy, Newspaper, Code, Monitor, Camera, Briefcase, MapPin, Phone, Mail, Globe, MessageCircle, Video, CheckCircle } from "lucide-react";
import Link from "next/link";
import SchoolLogo from "@/components/SchoolLogo";
import Navbar from "@/components/Navbar";
import { getWebSettings } from "@/app/admin/settings/actions";

export default async function Home() {
  const settings = await getWebSettings();
  const schoolName = settings?.schoolName || 'SMK GaMa';
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 font-sans">
      {/* Dynamic Navbar */}
      <Navbar />

      <main>
        {/* Hero Section */}
        <section className="relative pt-40 pb-16 lg:pt-48 lg:pb-24 overflow-hidden">
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-blue-950 opacity-90"></div>
            {/* Decorative blobs */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-400/20 rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2 animate-float"></div>
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-indigo-400/20 rounded-full blur-3xl transform -translate-x-1/2 translate-y-1/2 animate-float delay-500"></div>
          </div>
          
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 dark:text-white tracking-tight mb-8 animate-slide-up">
              Membangun Generasi <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400">
                Siap Kerja & Berprestasi
              </span>
            </h1>
            <p className="mt-4 text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-10 leading-relaxed animate-slide-up delay-100">
              Selamat datang di website resmi {schoolName}. Menjadi pusat keunggulan pendidikan kejuruan yang menghasilkan lulusan kompeten, inovatif, dan berkarakter.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 animate-slide-up delay-200">
              <Link href="/portofolio" className="px-8 py-4 bg-white dark:bg-gray-800 text-gray-900 dark:text-white rounded-full font-semibold border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2">
                Lihat Karya Siswa
              </Link>
              <Link href="/ppdb" className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-semibold shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 transition-all flex items-center justify-center gap-2">
                Informasi PPDB <ArrowRight size={20} />
              </Link>
            </div>
            {/* Statistik Section (Modern Glassmorphism) */}
            <div className="relative z-20 mt-16 lg:mt-24 mx-auto max-w-5xl text-left animate-zoom-in delay-300">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600 rounded-3xl blur-xl opacity-30 dark:opacity-50 animate-pulse"></div>
              <div className="relative py-10 bg-white/80 dark:bg-gray-900/80 backdrop-blur-2xl border border-white/50 dark:border-gray-800/50 rounded-3xl shadow-2xl">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-4 text-center divide-x-0 md:divide-x divide-gray-200 dark:divide-gray-800">
                  <div className="px-4 py-2 group cursor-default">
                    <div className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-br from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 mb-2 group-hover:scale-110 transition-transform duration-300">1,500+</div>
                    <div className="text-gray-600 dark:text-gray-400 font-bold text-xs md:text-sm tracking-widest uppercase">Siswa Aktif</div>
                  </div>
                  <div className="px-4 py-2 group cursor-default">
                    <div className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-br from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 mb-2 group-hover:scale-110 transition-transform duration-300">5</div>
                    <div className="text-gray-600 dark:text-gray-400 font-bold text-xs md:text-sm tracking-widest uppercase">Program Keahlian</div>
                  </div>
                  <div className="px-4 py-2 group cursor-default">
                    <div className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-br from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 mb-2 group-hover:scale-110 transition-transform duration-300">50+</div>
                    <div className="text-gray-600 dark:text-gray-400 font-bold text-xs md:text-sm tracking-widest uppercase">Mitra Industri</div>
                  </div>
                  <div className="px-4 py-2 group cursor-default">
                    <div className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-br from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 mb-2 group-hover:scale-110 transition-transform duration-300">98%</div>
                    <div className="text-gray-600 dark:text-gray-400 font-bold text-xs md:text-sm tracking-widest uppercase">Keterserapan Kerja</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Feature Cards Section */}
        <section className="py-24 bg-white dark:bg-gray-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Layanan & Sistem Terintegrasi</h2>
              <div className="w-20 h-1 bg-blue-600 mx-auto rounded-full"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {/* PPDB Card */}
              <div className="group p-8 rounded-3xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 hover:border-blue-500 hover:shadow-2xl transition-all duration-300 cursor-pointer animate-slide-up delay-100">
                <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <GraduationCap size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">PPDB Online</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6 line-clamp-3">
                  Sistem pendaftaran peserta didik baru terpadu. Proses mudah, transparan, dan dapat diakses dari mana saja.
                </p>
                <Link href="/ppdb" className="flex items-center text-blue-600 dark:text-blue-400 font-semibold group-hover:translate-x-2 transition-transform">
                  Buka Portal <ArrowRight size={18} className="ml-2" />
                </Link>
              </div>

              {/* Portal Siswa & Guru */}
              <div className="group p-8 rounded-3xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 hover:border-indigo-500 hover:shadow-2xl transition-all duration-300 cursor-pointer animate-slide-up delay-200">
                <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <LayoutDashboard size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Portal Akademik</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6 line-clamp-3">
                  Akses jadwal pelajaran, transkrip nilai, e-learning, dan absensi khusus untuk siswa dan guru.
                </p>
                <Link href="/login" className="flex items-center text-indigo-600 dark:text-indigo-400 font-semibold group-hover:translate-x-2 transition-transform">
                  Login Sistem <ArrowRight size={18} className="ml-2" />
                </Link>
              </div>

              {/* Berita */}
              <div className="group p-8 rounded-3xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 hover:border-amber-500 hover:shadow-2xl transition-all duration-300 cursor-pointer animate-slide-up delay-300">
                <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Newspaper size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Berita & Informasi</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6 line-clamp-3">
                  Pengumuman resmi, kegiatan ekstrakurikuler, dan update berita terkini dari lingkungan sekolah.
                </p>
                <Link href="/berita" className="flex items-center text-amber-600 dark:text-amber-400 font-semibold group-hover:translate-x-2 transition-transform">
                  Baca Berita <ArrowRight size={18} className="ml-2" />
                </Link>
              </div>

              {/* Prestasi & Galeri */}
              <div className="group p-8 rounded-3xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 hover:border-emerald-500 hover:shadow-2xl transition-all duration-300 cursor-pointer animate-slide-up delay-400">
                <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Trophy size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Galeri Prestasi</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6 line-clamp-3">
                  Dokumentasi kegiatan siswa, fasilitas sekolah, dan capaian prestasi tingkat nasional maupun internasional.
                </p>
                <Link href="/berita" className="flex items-center text-emerald-600 dark:text-emerald-400 font-semibold group-hover:translate-x-2 transition-transform">
                  Lihat Galeri <ArrowRight size={18} className="ml-2" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Program Keahlian Section (NEW) */}
        <section className="py-20 bg-gray-50 dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Program Keahlian</h2>
              <div className="w-20 h-1 bg-blue-600 mx-auto rounded-full mb-6"></div>
              <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">Kami menyediakan berbagai program keahlian yang disesuaikan dengan kebutuhan industri masa kini untuk mencetak tenaga kerja profesional.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* RPL */}
              <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 border border-gray-100 dark:border-gray-800 hover:shadow-xl hover:border-blue-500 transition-all group animate-slide-right delay-100">
                <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Code size={28} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Rekayasa Perangkat Lunak</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6 text-sm">Fokus pada pembuatan aplikasi web, mobile, dan desktop serta pemahaman struktur basis data dan algoritma pemrograman.</p>
                <ul className="space-y-3 text-sm text-gray-700 dark:text-gray-300 font-medium">
                  <li className="flex items-center gap-3"><CheckCircle size={18} className="text-green-500"/> Fullstack Web Development</li>
                  <li className="flex items-center gap-3"><CheckCircle size={18} className="text-green-500"/> Android/iOS Mobile Apps</li>
                  <li className="flex items-center gap-3"><CheckCircle size={18} className="text-green-500"/> Database & Cloud System</li>
                </ul>
              </div>

              {/* TKJ */}
              <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 border border-gray-100 dark:border-gray-800 hover:shadow-xl hover:border-indigo-500 transition-all group animate-slide-right delay-200">
                <div className="w-14 h-14 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Monitor size={28} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Teknik Komputer Jaringan</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6 text-sm">Mempelajari perakitan komputer, instalasi jaringan lokal (LAN) hingga skala luas (WAN), serta administrasi server Linux/Windows.</p>
                <ul className="space-y-3 text-sm text-gray-700 dark:text-gray-300 font-medium">
                  <li className="flex items-center gap-3"><CheckCircle size={18} className="text-green-500"/> Network Administrator</li>
                  <li className="flex items-center gap-3"><CheckCircle size={18} className="text-green-500"/> Server & Cloud Architecture</li>
                  <li className="flex items-center gap-3"><CheckCircle size={18} className="text-green-500"/> Cyber Security Dasar</li>
                </ul>
              </div>

              {/* Multimedia */}
              <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 border border-gray-100 dark:border-gray-800 hover:shadow-xl hover:border-amber-500 transition-all group animate-slide-right delay-300">
                <div className="w-14 h-14 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Camera size={28} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Multimedia / DKV</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6 text-sm">Berkaitan erat dengan desain grafis, animasi, editing video, dan fotografi yang banyak dicari oleh industri kreatif digital.</p>
                <ul className="space-y-3 text-sm text-gray-700 dark:text-gray-300 font-medium">
                  <li className="flex items-center gap-3"><CheckCircle size={18} className="text-green-500"/> Graphic & UI/UX Design</li>
                  <li className="flex items-center gap-3"><CheckCircle size={18} className="text-green-500"/> Video Editing & Production</li>
                  <li className="flex items-center gap-3"><CheckCircle size={18} className="text-green-500"/> 2D & 3D Animation</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Mitra Industri Section (NEW) */}
        <section className="py-16 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 mb-8 uppercase tracking-widest">Lulusan Kami Dipercaya & Bekerja di Berbagai Perusahaan</h3>
            <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-60 grayscale hover:grayscale-0 transition-all duration-700">
              <div className="text-2xl font-black text-gray-900 dark:text-white flex items-center gap-2"><Briefcase className="text-blue-600" /> TechNesia</div>
              <div className="text-2xl font-black text-gray-900 dark:text-white flex items-center gap-2"><Briefcase className="text-blue-600" /> CyberNet</div>
              <div className="text-2xl font-black text-gray-900 dark:text-white flex items-center gap-2"><Briefcase className="text-blue-600" /> Kreativ Studio</div>
              <div className="text-2xl font-black text-gray-900 dark:text-white flex items-center gap-2"><Briefcase className="text-blue-600" /> Nusa Corp</div>
              <div className="text-2xl font-black text-gray-900 dark:text-white flex items-center gap-2"><Briefcase className="text-blue-600" /> AlphaTech</div>
            </div>
          </div>
        </section>

        {/* Highlight Berita Terbaru (NEW) */}
        <section className="py-24 bg-gray-50 dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-12 gap-4">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Berita Terbaru</h2>
                <div className="w-20 h-1 bg-blue-600 rounded-full"></div>
              </div>
              <Link href="/berita" className="flex items-center text-blue-600 font-semibold hover:text-blue-700 group">
                Lihat Semua Berita <ArrowRight size={18} className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { 
                  id: 1, 
                  title: 'Pendaftaran PPDB Gelombang 1 Resmi Dibuka', 
                  category: 'Pengumuman',
                  date: '5 Oktober 2026', 
                  image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800&q=80'
                },
                { 
                  id: 2, 
                  title: 'Tim Robotik SMK Raih Juara 1 Nasional', 
                  category: 'Prestasi',
                  date: '1 Oktober 2026', 
                  image: 'https://images.unsplash.com/photo-1581092921461-eab62e97a780?w=800&q=80'
                },
                { 
                  id: 3, 
                  title: 'Kunjungan Industri ke PT. Teknologi Indonesia', 
                  category: 'Kegiatan',
                  date: '28 September 2026', 
                  image: 'https://images.unsplash.com/photo-1573164713988-8665fc963095?w=800&q=80'
                }
              ].map((item) => (
                <div key={item.id} className="bg-white dark:bg-gray-900 rounded-3xl overflow-hidden border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-xl transition-all group cursor-pointer">
                  <div className="h-48 relative overflow-hidden">
                    <Image src={item.image} alt="News" fill sizes="(max-width: 768px) 100vw, 33vw" className="object-cover group-hover:scale-105 transition-transform duration-700" />
                    <div className="absolute top-4 left-4 bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-sm">
                      {item.category}
                    </div>
                  </div>
                  <div className="p-6">
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-3 gap-2">
                      <Calendar size={14} /> {item.date}
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {item.title}
                    </h3>
                    <div className="flex items-center text-blue-600 font-medium text-sm mt-4">
                      Baca Selengkapnya <ArrowRight size={16} className="ml-1" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Expanded Footer (NEW) */}
      <footer className="bg-gray-950 pt-20 pb-10 border-t border-gray-900 text-gray-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            
            {/* Brand Info */}
            <div className="lg:col-span-1">
              <div className="flex items-center gap-3 mb-6">
                <SchoolLogo logoUrl={settings?.logoUrl} />
                <span className="font-bold text-2xl text-white">{schoolName}</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed mb-6">
                Mencetak generasi muda yang kompeten, berkarakter, dan siap bersaing di dunia industri kreatif dan teknologi masa depan.
              </p>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-gray-900 border border-gray-800 flex items-center justify-center hover:bg-blue-600 hover:border-blue-600 text-gray-400 hover:text-white transition-all">
                  <MessageCircle size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-gray-900 border border-gray-800 flex items-center justify-center hover:bg-blue-600 hover:border-blue-600 text-gray-400 hover:text-white transition-all">
                  <Video size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-gray-900 border border-gray-800 flex items-center justify-center hover:bg-blue-600 hover:border-blue-600 text-gray-400 hover:text-white transition-all">
                  <Globe size={18} />
                </a>
              </div>
            </div>
            
            {/* Quick Links */}
            <div>
              <h4 className="text-white font-bold mb-6 text-lg">Tautan Cepat</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li><Link href="/" className="hover:text-blue-400 transition-colors flex items-center gap-2"><ArrowRight size={14}/> Beranda</Link></li>
                <li><Link href="/berita" className="hover:text-blue-400 transition-colors flex items-center gap-2"><ArrowRight size={14}/> Berita & Pengumuman</Link></li>
                <li><Link href="/ppdb" className="hover:text-blue-400 transition-colors flex items-center gap-2"><ArrowRight size={14}/> Pendaftaran (PPDB)</Link></li>
                <li><Link href="/login" className="hover:text-blue-400 transition-colors flex items-center gap-2"><ArrowRight size={14}/> Portal Akademik</Link></li>
              </ul>
            </div>

            {/* Majors */}
            <div>
              <h4 className="text-white font-bold mb-6 text-lg">Program Keahlian</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div> Rekayasa Perangkat Lunak</li>
                <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-indigo-500"></div> Teknik Komputer Jaringan</li>
                <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-amber-500"></div> Multimedia / DKV</li>
                <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div> Akuntansi & Keuangan</li>
                <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-purple-500"></div> Otomatisasi Perkantoran</li>
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="text-white font-bold mb-6 text-lg">Kontak & Lokasi</h4>
              <ul className="space-y-4 text-sm text-gray-400">
                <li className="flex items-start gap-3">
                  <MapPin size={18} className="text-blue-500 mt-0.5 flex-shrink-0" />
                  <span className="leading-relaxed">Jl. Pendidikan No. 123, Kota Cerdas, Provinsi Teknologi, 12345</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone size={18} className="text-blue-500 flex-shrink-0" />
                  <span>(021) 555-0123</span>
                </li>
                <li className="flex items-center gap-3">
                  <Mail size={18} className="text-blue-500 flex-shrink-0" />
                  <span>info@smkbisa.sch.id</span>
                </li>
              </ul>
            </div>
            
          </div>
        </div>
      </footer>
    </div>
  );
}
