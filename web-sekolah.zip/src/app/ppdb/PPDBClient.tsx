'use client';

import { useState } from 'react';
import { User, CreditCard, Calendar, MapPin, School, BookOpen, Phone, UploadCloud, CheckCircle2, Award, HeartHandshake, Loader2, QrCode } from "lucide-react";
import Link from "next/link";
import { useRouter } from 'next/navigation';

export default function PPDBClient({ schoolName = "SMK GaMa" }: { schoolName?: string }) {
  const router = useRouter();
  const [jalur, setJalur] = useState<'normal' | 'afirmasi' | 'beasiswa'>('normal');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [applicantData, setApplicantData] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());
    
    try {
      const res = await fetch('/api/ppdb', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result = await res.json();

      if (!res.ok) {
        alert(result.error || 'Terjadi kesalahan');
        setIsSubmitting(false);
        return;
      }

      setApplicantData(result.applicant);
      setIsSubmitting(false);

      if (jalur === 'normal') {
        setShowPayment(true);
      } else {
        router.push(`/ppdb/success?id=${result.applicant.id}&name=${encodeURIComponent(result.applicant.fullName)}`);
      }
    } catch (error) {
      alert('Gagal menghubungi server');
      setIsSubmitting(false);
    }
  };

  const handlePay = async () => {
    setIsSubmitting(true);
    
    try {
      const res = await fetch('/api/ppdb/pay', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id: applicantData.id }),
      });

      if (!res.ok) {
        throw new Error('Gagal memperbarui status pembayaran');
      }

      setIsSubmitting(false);
      setPaymentSuccess(true);
      
      setTimeout(() => {
        router.push(`/ppdb/success?id=${applicantData.id}&name=${encodeURIComponent(applicantData.fullName)}`);
      }, 1000);
    } catch (error) {
      alert('Gagal menghubungi server untuk pembayaran');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 font-sans py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-10">
          <Link href="/" className="inline-block mb-6 text-blue-600 dark:text-blue-400 hover:underline font-medium">
            &larr; Kembali ke Beranda
          </Link>
          <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white mb-4">
            Pendaftaran Peserta Didik Baru
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            Tahun Ajaran 2026/2027. Silakan lengkapi formulir di bawah ini dengan data yang valid.
          </p>
        </div>

        {/* Form Container */}
        <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800 overflow-hidden relative">
          
          <div className="bg-blue-600 p-6 text-white text-center sm:text-left flex flex-col sm:flex-row items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">Formulir Pendaftaran</h2>
              <p className="text-blue-100 text-sm">Pastikan NISN dan nama sesuai ijazah</p>
            </div>
            <div className="mt-4 sm:mt-0 px-4 py-2 bg-white/20 rounded-full font-medium text-sm backdrop-blur-sm">
              Gelombang 1: Dibuka
            </div>
          </div>

          <div className="p-6 sm:px-10 pt-8 pb-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50">
            <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">Pilih Jalur Pendaftaran</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button 
                type="button"
                onClick={() => setJalur('normal')}
                className={`p-4 rounded-xl border-2 text-left transition-all ${jalur === 'normal' ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-200 dark:border-gray-700 hover:border-blue-300'}`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <User size={18} className={jalur === 'normal' ? 'text-blue-600' : 'text-gray-400'} />
                  <span className={`font-bold ${jalur === 'normal' ? 'text-blue-700 dark:text-blue-400' : 'text-gray-700 dark:text-gray-300'}`}>Reguler</span>
                </div>
                <p className="text-xs text-gray-500">Jalur umum menggunakan nilai rapor.</p>
              </button>

              <button 
                type="button"
                onClick={() => setJalur('afirmasi')}
                className={`p-4 rounded-xl border-2 text-left transition-all ${jalur === 'afirmasi' ? 'border-green-600 bg-green-50 dark:bg-green-900/20' : 'border-gray-200 dark:border-gray-700 hover:border-green-300'}`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <HeartHandshake size={18} className={jalur === 'afirmasi' ? 'text-green-600' : 'text-gray-400'} />
                  <span className={`font-bold ${jalur === 'afirmasi' ? 'text-green-700 dark:text-green-400' : 'text-gray-700 dark:text-gray-300'}`}>Afirmasi</span>
                </div>
                <p className="text-xs text-gray-500">Khusus pemegang KIP/SKTM/PKH.</p>
              </button>

              <button 
                type="button"
                onClick={() => setJalur('beasiswa')}
                className={`p-4 rounded-xl border-2 text-left transition-all ${jalur === 'beasiswa' ? 'border-purple-600 bg-purple-50 dark:bg-purple-900/20' : 'border-gray-200 dark:border-gray-700 hover:border-purple-300'}`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Award size={18} className={jalur === 'beasiswa' ? 'text-purple-600' : 'text-gray-400'} />
                  <span className={`font-bold ${jalur === 'beasiswa' ? 'text-purple-700 dark:text-purple-400' : 'text-gray-700 dark:text-gray-300'}`}>Prestasi/Beasiswa</span>
                </div>
                <p className="text-xs text-gray-500">Jalur khusus dengan sertifikat prestasi.</p>
              </button>
            </div>
          </div>

          <form className="p-6 sm:p-10 space-y-8" onSubmit={handleSubmit}>
            <input type="hidden" name="jalurPendaftaran" value={jalur} />
            
            {/* Data Pribadi */}
            <section>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2 border-b border-gray-200 dark:border-gray-700 pb-2">
                <User className="text-blue-600" size={20} /> Data Pribadi
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Nama Lengkap</label>
                  <input required type="text" name="fullName" className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all dark:text-white" placeholder="Masukkan nama lengkap" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">NISN</label>
                  <input required type="number" name="nisn" className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all dark:text-white" placeholder="Nomor Induk Siswa Nasional" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Tempat, Tanggal Lahir</label>
                  <input required type="text" name="birthInfo" className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all dark:text-white" placeholder="Contoh: Jakarta, 12 Agustus 2010" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Jenis Kelamin</label>
                  <select required name="gender" className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all dark:text-white">
                    <option value="">Pilih Jenis Kelamin</option>
                    <option value="L">Laki-laki</option>
                    <option value="P">Perempuan</option>
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Alamat Lengkap</label>
                  <textarea required name="address" rows={3} className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all dark:text-white" placeholder="Masukkan alamat domisili"></textarea>
                </div>
              </div>
            </section>

            {/* Syarat Khusus Jalur */}
            {(jalur === 'afirmasi' || jalur === 'beasiswa') && (
              <section className={`p-6 rounded-2xl border ${jalur === 'afirmasi' ? 'bg-green-50/50 border-green-200 dark:bg-green-900/10 dark:border-green-900' : 'bg-purple-50/50 border-purple-200 dark:bg-purple-900/10 dark:border-purple-900'}`}>
                <h3 className={`text-lg font-bold mb-4 flex items-center gap-2 border-b pb-2 ${jalur === 'afirmasi' ? 'text-green-800 border-green-200 dark:text-green-400 dark:border-green-800' : 'text-purple-800 border-purple-200 dark:text-purple-400 dark:border-purple-800'}`}>
                  {jalur === 'afirmasi' ? <HeartHandshake size={20} /> : <Award size={20} />} 
                  Syarat Khusus Jalur {jalur === 'afirmasi' ? 'Afirmasi' : 'Prestasi'}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {jalur === 'afirmasi' && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Nomor KIP / PKH / KKS</label>
                        <input required type="text" name="afirmasiNumber" className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-green-500 outline-none transition-all dark:text-white" placeholder="Masukkan Nomor Kartu" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Scan Dokumen KIP/SKTM (PDF/JPG)</label>
                        <div className="w-full px-4 py-3 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 flex flex-col items-center justify-center cursor-pointer hover:border-green-500 transition-colors">
                          <UploadCloud className="text-gray-400 mb-1" size={24} />
                          <span className="text-xs text-gray-500">Pilih File SKTM/KIP</span>
                        </div>
                      </div>
                    </>
                  )}

                  {jalur === 'beasiswa' && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Jenis & Tingkat Prestasi</label>
                        <input required type="text" name="prestasiType" className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-purple-500 outline-none transition-all dark:text-white" placeholder="Contoh: Juara 1 OSN Matematika Tingkat Provinsi" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Scan Sertifikat/Piagam (PDF/JPG)</label>
                        <div className="w-full px-4 py-3 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 flex flex-col items-center justify-center cursor-pointer hover:border-purple-500 transition-colors">
                          <UploadCloud className="text-gray-400 mb-1" size={24} />
                          <span className="text-xs text-gray-500">Upload Sertifikat</span>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </section>
            )}

            {/* Data Akademik */}
            <section>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2 border-b border-gray-200 dark:border-gray-700 pb-2">
                <School className="text-blue-600" size={20} /> Data Akademik & Pilihan Jurusan
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Asal Sekolah (SMP/MTs)</label>
                  <input required type="text" name="previousSchool" className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all dark:text-white" placeholder="Nama asal sekolah" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Pilihan Jurusan Prioritas</label>
                  <select required name="major" className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all dark:text-white">
                    <option value="">Pilih Program Keahlian</option>
                    <option value="RPL">Rekayasa Perangkat Lunak (RPL)</option>
                    <option value="TKJ">Teknik Komputer & Jaringan (TKJ)</option>
                    <option value="MM">Multimedia (Desain Komunikasi Visual)</option>
                    <option value="AK">Akuntansi & Keuangan Lembaga</option>
                    <option value="OTKP">Otomatisasi & Tata Kelola Perkantoran</option>
                  </select>
                </div>
              </div>
            </section>

            {/* Kontak & Dokumen */}
            <section>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2 border-b border-gray-200 dark:border-gray-700 pb-2">
                <Phone className="text-blue-600" size={20} /> Kontak & Berkas Utama
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Nomor Telepon/WhatsApp</label>
                  <input required type="tel" name="phone" className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all dark:text-white" placeholder="08xxxxxxxxxx" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Scan Kartu Keluarga (PDF/JPG)</label>
                  <div className="w-full px-4 py-2 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl bg-gray-50 dark:bg-gray-800/50 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                    <UploadCloud className="text-gray-400 mb-1" size={24} />
                    <span className="text-xs text-gray-500">Pilih File KK...</span>
                  </div>
                </div>
              </div>
            </section>

            {/* Checkbox Persetujuan */}
            <div className="flex items-start gap-3 mt-8 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
              <input required type="checkbox" id="terms" className="mt-1 w-5 h-5 text-blue-600 rounded focus:ring-blue-500" />
              <label htmlFor="terms" className="text-sm text-gray-700 dark:text-gray-300">
                Saya menyatakan bahwa data yang saya isikan adalah benar dan valid. Saya bersedia mengikuti seluruh tahapan seleksi PPDB {schoolName} sesuai dengan ketentuan yang berlaku, khususnya untuk jalur <span className="font-bold capitalize">{jalur === 'normal' ? 'Reguler' : jalur}</span>.
              </label>
            </div>

            {/* Submit Button */}
            <div className="pt-6 border-t border-gray-200 dark:border-gray-800 flex justify-end">
              <button 
                type="submit" 
                disabled={isSubmitting}
                className="px-8 py-4 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-xl font-bold shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 transition-all flex items-center gap-2 text-lg"
              >
                {isSubmitting ? (
                  <><Loader2 className="animate-spin" size={24} /> Memproses...</>
                ) : (
                  <><CheckCircle2 size={24} /> Kirim Pendaftaran</>
                )}
              </button>
            </div>
          </form>

          {/* Payment Gateway Modal (Midtrans Simulation) */}
          {showPayment && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-gray-900/60 backdrop-blur-sm p-4 animate-fade-in">
              <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-zoom-in">
                {/* Header Midtrans style */}
                <div className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-6 text-center relative">
                  <h3 className="font-bold text-gray-900 dark:text-white text-lg">Pembayaran PPDB</h3>
                  <p className="text-gray-500 text-sm mt-1">{schoolName} - Biaya Formulir Pendaftaran</p>
                  <button onClick={() => setShowPayment(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-700">✕</button>
                </div>
                
                {!paymentSuccess ? (
                  <div className="p-6">
                    <div className="text-center mb-6">
                      <div className="text-sm text-gray-500 mb-1">Total Tagihan</div>
                      <div className="text-3xl font-black text-gray-900 dark:text-white">Rp 150.000</div>
                      <div className="text-xs text-blue-600 mt-2 bg-blue-50 dark:bg-blue-900/30 py-1 px-3 rounded-full inline-block">ID: INV-{applicantData?.id?.toUpperCase()}</div>
                    </div>

                    <div className="space-y-3 mb-6">
                      <button onClick={handlePay} disabled={isSubmitting} className="w-full p-4 border border-gray-200 dark:border-gray-700 rounded-xl flex items-center justify-between hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all group">
                        <div className="flex items-center gap-3">
                          <QrCode className="text-blue-600" />
                          <span className="font-semibold text-gray-900 dark:text-white group-hover:text-blue-600">QRIS (GoPay, Dana, OVO)</span>
                        </div>
                        <span className="text-gray-400">&rarr;</span>
                      </button>
                      <button onClick={handlePay} disabled={isSubmitting} className="w-full p-4 border border-gray-200 dark:border-gray-700 rounded-xl flex items-center justify-between hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all group">
                        <div className="flex items-center gap-3">
                          <CreditCard className="text-blue-600" />
                          <span className="font-semibold text-gray-900 dark:text-white group-hover:text-blue-600">Virtual Account (Bank Transfer)</span>
                        </div>
                        <span className="text-gray-400">&rarr;</span>
                      </button>
                    </div>

                    {isSubmitting && (
                      <div className="text-center text-sm text-blue-600 flex items-center justify-center gap-2">
                        <Loader2 className="animate-spin" size={16} /> Sedang memverifikasi pembayaran...
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-8 text-center">
                    <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-zoom-in">
                      <CheckCircle2 size={40} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Pembayaran Berhasil!</h3>
                    <p className="text-gray-500 text-sm mb-6">Terima kasih, pembayaran formulir pendaftaran Anda telah dikonfirmasi.</p>
                    <div className="text-sm text-gray-400">Mengarahkan ke halaman sukses...</div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
        
      </div>
    </div>
  );
}
