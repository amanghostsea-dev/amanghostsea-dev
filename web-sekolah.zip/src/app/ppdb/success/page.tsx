import { CheckCircle, Download, Home, FileText } from "lucide-react";
import Link from "next/link";

export default async function PPDBSucceessPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const resolvedParams = await searchParams;
  const id = resolvedParams.id as string;
  const name = resolvedParams.name as string;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex flex-col items-center justify-center p-4">
      <div className="max-w-xl w-full bg-white dark:bg-gray-900 p-8 sm:p-12 rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-800 text-center">
        
        <div className="w-24 h-24 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle size={48} />
        </div>
        
        <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white mb-2">
          Pendaftaran Berhasil!
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mb-8 text-lg">
          Terima kasih <strong>{name || 'Calon Siswa'}</strong>, data pendaftaran Anda telah kami terima dan akan segera diproses oleh panitia PPDB.
        </p>

        <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-6 mb-8 border border-gray-200 dark:border-gray-700">
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Nomor Registrasi Anda:</p>
          <p className="text-2xl font-mono font-bold text-blue-600 dark:text-blue-400 tracking-wider">
            {id ? `PPDB-${id.slice(-6)}` : 'PPDB-XXXXXX'}
          </p>
          <p className="text-xs text-gray-500 mt-3">Simpan nomor registrasi ini untuk mengecek status kelulusan nanti.</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-all flex items-center justify-center gap-2">
            <Download size={20} /> Cetak Bukti Daftar
          </button>
          <Link href="/" className="px-6 py-3 bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl font-medium transition-all flex items-center justify-center gap-2">
            <Home size={20} /> Ke Beranda
          </Link>
        </div>
        
      </div>
    </div>
  );
}
