'use client'

import { Search, UserCheck, FileText, Filter, MoreVertical, CheckCircle, XCircle } from 'lucide-react';
import { updateSubmissionStatus } from './actions';
import { useState } from 'react';

export default function PPDBClient({ initialSubmissions }: { initialSubmissions: any[] }) {
  const [loadingId, setLoadingId] = useState<string | null>(null);

  const handleStatusChange = async (id: string, status: string) => {
    setLoadingId(id);
    try {
      await updateSubmissionStatus(id, status);
    } finally {
      setLoadingId(null);
    }
  };

  const pendingCount = initialSubmissions.filter((s: any) => s.status === 'PENDING').length;
  const approvedCount = initialSubmissions.filter((s: any) => s.status === 'APPROVED').length;

  return (
    <div className="p-8 md:p-10 font-sans">
      <div className="max-w-7xl mx-auto">
        
        {/* Header Dashboard */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-10 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Manajemen PPDB</h1>
            <p className="text-gray-500 dark:text-gray-400">Kelola data pendaftaran peserta didik baru.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-white dark:bg-gray-900 px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-800 flex items-center shadow-sm">
              <Search className="text-gray-400 mr-2" size={18} />
              <input type="text" placeholder="Cari nama atau NISN..." className="bg-transparent border-none outline-none text-sm dark:text-white w-full md:w-64" />
            </div>
            <button className="bg-white dark:bg-gray-900 p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 shadow-sm">
              <Filter size={20} />
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm flex items-center gap-4">
            <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full flex items-center justify-center">
              <FileText size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Pendaftar</p>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white">{initialSubmissions.length}</h3>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm flex items-center gap-4">
            <div className="w-14 h-14 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-full flex items-center justify-center">
              <UserCheck size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Menunggu Verifikasi</p>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white">{pendingCount}</h3>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm flex items-center gap-4">
            <div className="w-14 h-14 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center">
              <CheckCircle size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Diterima</p>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white">{approvedCount}</h3>
            </div>
          </div>
        </div>

        {/* Data Table */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 dark:bg-gray-800/50 border-b border-gray-200 dark:border-gray-800 text-sm font-medium text-gray-500 dark:text-gray-400">
                  <th className="py-4 px-6">ID Daftar</th>
                  <th className="py-4 px-6">Nama Lengkap</th>
                  <th className="py-4 px-6">Jalur & Jurusan</th>
                  <th className="py-4 px-6">Status Bayar</th>
                  <th className="py-4 px-6">Status PPDB</th>
                  <th className="py-4 px-6 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800 text-sm">
                {initialSubmissions.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-gray-500">Belum ada data pendaftar.</td>
                  </tr>
                ) : (
                  initialSubmissions.map((sub: any) => (
                    <tr key={sub.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                      <td className="py-4 px-6 font-mono text-xs text-gray-500">{sub.id.slice(-6)}</td>
                      <td className="py-4 px-6">
                        <p className="font-semibold text-gray-900 dark:text-white">{sub.fullName}</p>
                        <p className="text-xs text-gray-500">NISN: {sub.nisn}</p>
                      </td>
                      <td className="py-4 px-6">
                        <p className="text-gray-900 dark:text-gray-300 font-medium capitalize">{sub.jalur}</p>
                        <p className="text-xs text-gray-500">{sub.major}</p>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`px-3 py-1 text-xs rounded-full font-medium ${sub.paymentStatus === 'PAID' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                          {sub.paymentStatus}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`px-3 py-1 text-xs rounded-full font-medium ${
                          sub.status === 'APPROVED' ? 'bg-green-100 text-green-700' : 
                          sub.status === 'REJECTED' ? 'bg-red-100 text-red-700' : 
                          'bg-amber-100 text-amber-700'
                        }`}>
                          {sub.status}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-right">
                        <div className="flex justify-end gap-2">
                          {sub.status === 'PENDING' ? (
                            <>
                              <button onClick={() => handleStatusChange(sub.id, 'APPROVED')} disabled={loadingId === sub.id} className="text-sm bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 disabled:opacity-50">Terima</button>
                              <button onClick={() => handleStatusChange(sub.id, 'REJECTED')} disabled={loadingId === sub.id} className="text-sm bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 disabled:opacity-50">Tolak</button>
                            </>
                          ) : (
                            <button onClick={() => handleStatusChange(sub.id, 'PENDING')} disabled={loadingId === sub.id} className="text-sm bg-gray-200 text-gray-700 px-3 py-1 rounded hover:bg-gray-300 disabled:opacity-50">Batal</button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
