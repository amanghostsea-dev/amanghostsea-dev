'use server'

import { PrismaClient } from '@prisma/client'
import { revalidatePath } from 'next/cache'

const prisma = new PrismaClient();

export async function getSubmissions() {
  return await prisma.ppdbApplicant.findMany({
    orderBy: { createdAt: 'desc' }
  });
}

export async function updateSubmissionStatus(id: string, status: string) {
  await prisma.ppdbApplicant.update({
    where: { id },
    data: { status }
  });
  revalidatePath('/admin/ppdb');
}
