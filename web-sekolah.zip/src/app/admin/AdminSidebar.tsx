'use client';
import { Users, Settings, Database, Activity, LogOut, BookOpen, Network, LayoutDashboard, TrendingUp, Briefcase, ExternalLink } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import SchoolLogo from '@/components/SchoolLogo';

export default function AdminSidebar({ logoUrl }: { logoUrl?: string | null }) {
  const pathname = usePathname();

  const isActive = (path: string) => {
    if (path === '/admin' && pathname !== '/admin') return false;
    return pathname?.startsWith(path);
  };

  const menuItems = [
    { name: 'Dashboard Utama', path: '/admin', icon: <Activity size={20} /> },
    { name: 'Modul PPDB', path: '/admin/ppdb', icon: <Database size={20} /> },
    { name: 'BKK Lowongan', path: '/admin/bkk/jobs', icon: <Briefcase size={20} /> },
    { name: 'Tracer Study', path: '/admin/bkk/tracer-study', icon: <TrendingUp size={20} /> },
    { name: 'Manajemen Akun', path: '/admin/users', icon: <Users size={20} /> },
    { name: 'Manajemen Jurusan', path: '/admin/jurusan', icon: <BookOpen size={20} /> },
    { name: 'Manajemen Konten', path: '/admin/berita', icon: <LayoutDashboard size={20} /> },
    { name: 'Kelola Sambutan', path: '/admin/sambutan', icon: <Users size={20} /> },
    { name: 'Struktur Organisasi', path: '/admin/struktur', icon: <Network size={20} /> },
    { name: 'Pengaturan Web', path: '/admin/settings', icon: <Settings size={20} /> },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col h-screen sticky top-0 hidden md:flex flex-shrink-0 shadow-xl">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <SchoolLogo logoUrl={logoUrl} />
          <span className="font-bold text-xl tracking-tight">SuperAdmin</span>
        </div>
      </div>
      <div className="p-4 flex-1 space-y-1 overflow-y-auto custom-scrollbar">
        {menuItems.map((item) => (
          <Link
            key={item.path}
            href={item.path}
            className={`flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-all duration-200 ${
              isActive(item.path)
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {item.icon} {item.name}
          </Link>
        ))}
      </div>
      <div className="p-4 border-t border-slate-800 space-y-1">
        <Link href="/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 px-4 py-3 text-blue-400 hover:bg-slate-800 rounded-lg font-medium transition-colors">
          <ExternalLink size={20} /> Lihat Website
        </Link>
        <Link href="/" className="flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-slate-800 rounded-lg font-medium transition-colors">
          <LogOut size={20} /> Keluar
        </Link>
      </div>
    </aside>
  );
}
