import AdminSidebar from './AdminSidebar';
import { getWebSettings } from '@/app/admin/settings/actions';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const settings = await getWebSettings();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex font-sans">
      <AdminSidebar logoUrl={settings?.logoUrl} />

      {/* Main Content Area */}
      <div className="flex-1 w-full min-w-0">
         {children}
      </div>
    </div>
  );
}
