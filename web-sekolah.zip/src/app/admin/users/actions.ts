'use server'

import { PrismaClient } from '@prisma/client'
import { revalidatePath } from 'next/cache'

const prisma = new PrismaClient();

export async function getUsers() {
  return await prisma.user.findMany({
    orderBy: { createdAt: 'desc' }
  });
}

export async function createUser(data: any) {
  // We'll set a default password if not provided
  const password = data.password || '123456';
  
  await prisma.user.create({
    data: {
      name: data.name,
      username: data.username,
      role: data.role,
      status: data.status,
      password: password, // For simplicity in this demo, not hashing. If bcrypt is needed, I should install it.
    }
  });
  revalidatePath('/admin/users');
}

export async function updateUser(id: string, data: any) {
  await prisma.user.update({
    where: { id },
    data: {
      name: data.name,
      username: data.username,
      role: data.role,
      status: data.status,
      // We don't update password here unless explicitly given
    }
  });
  revalidatePath('/admin/users');
}

export async function deleteUser(id: string) {
  await prisma.user.delete({
    where: { id }
  });
  revalidatePath('/admin/users');
}
