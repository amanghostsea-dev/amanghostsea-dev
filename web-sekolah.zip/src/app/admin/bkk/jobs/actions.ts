'use server'

import { PrismaClient } from '@prisma/client'
import { revalidatePath } from 'next/cache'

const prisma = new PrismaClient();

export async function createJob(data: any) {
  await prisma.jobListing.create({
    data: {
      title: data.title,
      company: data.company,
      location: data.location,
      salary: data.salary,
      type: data.type,
      description: data.description,
      tags: data.tags,
      isHot: data.isHot,
    }
  });
  revalidatePath('/admin/bkk/jobs');
}

export async function updateJob(id: string, data: any) {
  await prisma.jobListing.update({
    where: { id },
    data: {
      title: data.title,
      company: data.company,
      location: data.location,
      salary: data.salary,
      type: data.type,
      description: data.description,
      tags: data.tags,
      isHot: data.isHot,
    }
  });
  revalidatePath('/admin/bkk/jobs');
}

export async function deleteJob(id: string) {
  await prisma.jobListing.delete({
    where: { id }
  });
  revalidatePath('/admin/bkk/jobs');
}
