import { PrismaClient } from "@prisma/client";
import JurusanClient from "./JurusanClient";

const prisma = new PrismaClient();
export const dynamic = "force-dynamic";

export default async function JurusanPage() {
  const initialJurusan = await prisma.jurusan.findMany({
    orderBy: { createdAt: "desc" },
  });

  return <JurusanClient initialJurusan={initialJurusan} />;
}
