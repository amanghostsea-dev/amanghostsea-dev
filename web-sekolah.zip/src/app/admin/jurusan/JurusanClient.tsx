'use client';

import { useState } from 'react';
import { BookOpen, Plus, Edit2, Trash2, X, Check, Search, ArrowLeft } from 'lucide-react';
import { createJurusan, updateJurusan, deleteJurusan } from './actions';

export default function JurusanClient({ initialJurusan }: { initialJurusan: any[] }) {
  const [jurusan, setJurusan] = useState(initialJurusan);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({ id: '', name: '', code: '', description: '', kuota: 0 });
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleAdd = () => {
    setFormData({ id: '', name: '', code: '', description: '', kuota: 0 });
    setIsEditing(false);
    setIsModalOpen(true);
  };

  const handleEdit = (item: any) => {
    setFormData({
      id: item.id,
      name: item.name,
      code: item.code,
      description: item.description,
      kuota: item.kuota
    });
    setIsEditing(true);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if(confirm('Yakin ingin menghapus jurusan ini?')) {
      await deleteJurusan(id);
      setJurusan(jurusan.filter(j => j.id !== id));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    if (isEditing) {
      const res = await updateJurusan(formData.id, formData);
      if (res.success) {
        setJurusan(jurusan.map(j => j.id === formData.id ? res.data : j));
      } else {
        alert(res.error);
      }
    } else {
      const res = await createJurusan(formData);
      if (res.success) {
        setJurusan([res.data, ...jurusan]);
      } else {
        alert(res.error);
      }
    }
    
    setLoading(false);
    setIsModalOpen(true); // wait, should close modal
    setIsModalOpen(false);
  };

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <BookOpen className="text-green-600" /> Manajemen Jurusan
            </h1>
            <p className="text-gray-500 text-sm">Kelola program keahlian dan kuota penerimaan siswa</p>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-6 border-b border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-72">
              <input type="text" placeholder="Cari jurusan..." className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 outline-none" />
              <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
            </div>
            <button onClick={handleAdd} className="w-full sm:w-auto px-4 py-2 bg-green-600 text-white rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-green-700 transition-colors">
              <Plus size={18} /> Tambah Jurusan
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 text-gray-600 border-b border-gray-200">
                  <th className="p-4 font-medium">Nama Jurusan</th>
                  <th className="p-4 font-medium">Kode Singkatan</th>
                  <th className="p-4 font-medium">Deskripsi Singkat</th>
                  <th className="p-4 font-medium">Kuota Siswa</th>
                  <th className="p-4 font-medium text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {jurusan.map(item => (
                  <tr key={item.id} className="hover:bg-gray-50">
                    <td className="p-4 font-bold text-gray-900">{item.name}</td>
                    <td className="p-4">
                      <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">
                        {item.code}
                      </span>
                    </td>
                    <td className="p-4 text-gray-500 text-sm max-w-xs truncate">{item.description}</td>
                    <td className="p-4 font-medium text-gray-700">{item.kuota} Kursi</td>
                    <td className="p-4">
                      <div className="flex items-center justify-center gap-2">
                        <button onClick={() => handleEdit(item)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"><Edit2 size={16} /></button>
                        <button onClick={() => handleDelete(item.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"><Trash2 size={16} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                <h3 className="text-lg font-bold text-gray-900">{isEditing ? 'Edit Jurusan' : 'Tambah Jurusan Baru'}</h3>
                <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
              </div>
              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nama Program Keahlian</label>
                  <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 outline-none" placeholder="Cth: Teknik Komputer dan Jaringan" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Kode Singkatan</label>
                    <input required type="text" value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 outline-none" placeholder="Cth: TKJ" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Kuota PPDB</label>
                    <input required type="number" value={formData.kuota} onChange={e => setFormData({...formData, kuota: Number(e.target.value)})} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 outline-none" min="0" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Deskripsi Jurusan</label>
                  <textarea required value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 outline-none h-24 resize-none" placeholder="Penjelasan singkat mengenai jurusan ini..." />
                </div>
                <div className="pt-4 flex justify-end gap-3">
                  <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors">Batal</button>
                  <button type="submit" disabled={loading} className="px-4 py-2 text-white bg-green-600 hover:bg-green-700 rounded-lg font-medium transition-colors flex items-center gap-2">
                    {loading ? 'Menyimpan...' : <><Check size={18} /> Simpan</>}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
