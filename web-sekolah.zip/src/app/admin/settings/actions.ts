'use server';

import { PrismaClient } from '@prisma/client';
import { revalidatePath } from 'next/cache';

const prisma = new PrismaClient();

export async function saveWebSettings(data: any) {
  try {
    const value = JSON.stringify(data);
    await prisma.setting.upsert({
      where: { key: 'webSettings' },
      update: { value },
      create: {
        key: 'webSettings',
        value,
        description: 'Web Settings (Logo, Name, Tagline)',
      },
    });
    revalidatePath('/', 'layout');
    return { success: true };
  } catch (error: any) {
    return { error: error.message };
  }
}

export async function getWebSettings() {
  const setting = await prisma.setting.findUnique({
    where: { key: 'webSettings' },
  });
  if (setting) {
    return JSON.parse(setting.value);
  }
  return null;
}
